//
//  textField1Delegate.swift
//  Meme v1.
//
//  Created by Simon Wells on 2020/4/25.
//  Copyright © 2020 Simon Wells. All rights reserved.
//

import Foundation
import UIKit

class textField1Delegate: NSObject, UITextFieldDelegate {
}
